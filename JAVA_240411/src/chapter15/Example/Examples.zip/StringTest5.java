package chapter15.Example;

/*
 * 문제5

파일 이름 : soldesk
도메인 이름 : studesk.com

 */
public class StringTest5 {

	public static void main(String[] args) {
		
		//문자열을 @를 기준으로 나누시오
		String str = "soldesk@studesk.com";
		
		String[] split = str.split("@");
		System.out.println("파일 이름: " + split[0]);
		System.out.println("도메인 이름: " + split[1]);

	}

}
