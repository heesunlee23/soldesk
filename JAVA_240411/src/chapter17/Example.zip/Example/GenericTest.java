package chapter17.Example;

public class GenericTest<T> {
	
	private Human human;
	
	public void act() {
		human.act();
	}

	public Human getHuman() {
		return human;
	}

	public void setHuman(Human human) {
		this.human = human;
	}
}
