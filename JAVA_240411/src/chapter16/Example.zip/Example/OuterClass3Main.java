package chapter16.Example;

// 참고: https://ittrue.tistory.com/123
public class OuterClass3Main {

	// 지역클래스 LocalClass를 구현하고 hello() 메서드를 호출하세요
	public static void main(String[] args) {
		
		OuterClass3 outerClass3 = new OuterClass3();
		outerClass3.myMethod();

	}

}