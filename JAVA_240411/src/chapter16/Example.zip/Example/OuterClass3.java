package chapter16.Example;

public class OuterClass3 {

	public void myMethod() {
		class NestedClass {
			void getString() {
				System.out.println("Hello World | 지역클래스");
			}
		}
		NestedClass nc = new NestedClass();
		nc.getString();
	}

}
