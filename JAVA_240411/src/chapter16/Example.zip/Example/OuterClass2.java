package chapter16.Example;

public class OuterClass2 {
	private LocalClass localClass;
	
	public void myMethod() {
		localClass = new LocalClass();
		localClass.hello();
	}
	
	// 지역클래스 LocalClass를 구현하고 hello() 메서드를 호출하세요
	class LocalClass {
		void hello() {
			System.out.println("Hello World | 내부클래스");
		}
	}
}
