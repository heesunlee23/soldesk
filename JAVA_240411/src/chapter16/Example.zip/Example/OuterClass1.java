package chapter16.Example;

public class OuterClass1 {
	static class NestedClass{
		void hello() {
			System.out.println("Hello World | 정적중첩클래스");
		}	
	}
}
